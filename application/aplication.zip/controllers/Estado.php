<?php

/**
 * Created by PhpStorm.
 * User: carola
 * Date: 4/11/15
 * Time: 2:34 AM
 */
class Estado
{

}