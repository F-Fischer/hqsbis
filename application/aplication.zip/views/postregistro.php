<header id='POSTREGISTRO'>
    <div class="header-content">
        <div class="header-content-inner">
            <h1 style="color:#0404B4">Felicitaciones!</h1>
            <hr>
            <p style="color:#8904B1">
                <b> Ya casi eres parte de nuestra plataforma. Ve a tu cuenta de correo e ingresa al link que te hemos enviado. </b>
            </p>
            <a href="<?php echo base_url('welcome') ?>" class="btn btn-primary btn-xl page-scroll">Volver al inicio</a>
        </div>
    </div>
</header>

